# --- Created by Ebean DDL
# To stop Ebean DDL generation, remove this comment and start using Evolutions

# --- !Ups

create table app_oauth_token (
  oauth_token               varchar(255) not null,
  oauth_token_secret        varchar(255),
  constraint pk_app_oauth_token primary key (oauth_token))
;

create sequence app_oauth_token_seq;




# --- !Downs

SET REFERENTIAL_INTEGRITY FALSE;

drop table if exists app_oauth_token;

SET REFERENTIAL_INTEGRITY TRUE;

drop sequence if exists app_oauth_token_seq;

