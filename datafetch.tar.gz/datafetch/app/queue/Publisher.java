package queue;

import com.rabbitmq.client.*;
import helper.Serializer;
import helper.TweetWrapper;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Publisher {

    private String queueName;
    private Channel channel;
    private Connection connection;
    public static int number_of_tweet=0;
    public Publisher(String queueName) throws IOException {
        this.queueName = queueName;
        ConnectionFactory factory = new ConnectionFactory();
        factory.setHost("localhost");

        connection = factory.newConnection();
        channel = connection.createChannel();

        channel.queueDeclare(queueName, false, false, false, null);
    }

    public void pushToQueue(TweetWrapper tweetWrapper) throws IOException {
        channel.basicPublish("", queueName, null, Serializer.serialize(tweetWrapper));
        //System.out.println("number of tweet in the queue: "+ ++number_of_tweet +" "+ LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS")));
        //System.out.println("publishing part"+tweetWrapper);
    }

    public void publish(String text) throws IOException {
        channel.basicPublish("", queueName, null, text.getBytes());
    }

    public void closeQueue() throws IOException {
        channel.close();
        connection.close();
    }
}