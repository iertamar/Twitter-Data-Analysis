package analytics;

import com.rabbitmq.client.QueueingConsumer;
import data.*;
import helper.Serializer;
import helper.TweetWrapper;
import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import queue.Subscriber;
import twitter4j.Status;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.regex.Matcher;

public class Analytics {
    static Logger logger = Logger.getLogger(Analytics.class.getName());
    static int tweetsCount = 0;

    private static void analyzeData(TweetWrapper tweetWrapper){

        List<Integer> presentEntities = findEntity(tweetWrapper);
        TalkersRepo.talkers(tweetWrapper, presentEntities);
        TweetRepository.mostRetweetedTweets(tweetWrapper, presentEntities);//System.out.println("Hashtag start at: "+LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS")));
        RecentHashtags.hashtags(tweetWrapper, presentEntities);


        GeoRepo.geoAnalysis(tweetWrapper, presentEntities);
        Sentiment.sentimentAnalysis(tweetWrapper, presentEntities);
        ImageRepo.imageAnalysis(tweetWrapper, presentEntities);
        TopicsRepo.trendingTopics(tweetWrapper, presentEntities);

        tweetsCount++;
        if (tweetsCount == 100){
            tweetsCount = 0;
            logger.debug("Current time:" + new Date() + "\tTweet time:" + tweetWrapper.status.getCreatedAt());
        }
    }

    private static String getOriginalTweet(Status status){
        if (status.isRetweet())
            return status.getRetweetedStatus().getText();
        else return status.getText();
    }

    private static List<Integer> findEntity(TweetWrapper tweetWrapper) {
        Status status = tweetWrapper.status;
        String text = getOriginalTweet(status);
        List<Integer> presentEntities = new ArrayList<>();
        List<Integer> entities = EntityRepo.getEntitiesForUser(tweetWrapper.requestId);
        for (Integer entity : entities) {
            Matcher matcher = KeywordRepository.getPatternForEntity(entity).matcher(text);
            if (matcher.find()) {
                presentEntities.add(entity);
            }
        }
        System.out.println("entities found");
        return presentEntities;
    }

    private static void receiveFromQueue(Subscriber subscriber) throws IOException, ClassNotFoundException, InterruptedException {
        while (true) {
            System.out.println("Getting tweet from RabbitMQ: "+ LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS")));
            QueueingConsumer.Delivery delivery = subscriber.getConsumer().nextDelivery();
            //System.out.println(delivery);
            TweetWrapper tweetWrapper = (TweetWrapper) Serializer.deserialize(delivery.getBody());
            //System.out.println(QueueingConsumer.Delivery);
            System.out.println("Start of functionality: "+ LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS")));
            //System.out.println(tweetWrapper.status);
            Analytics.analyzeData(tweetWrapper);
        }
    }

    public static void main() throws IOException, InterruptedException, ClassNotFoundException {
        //SystemApplicationContext context = new ClassPathXmlApplicationContext("spring-config.xml");
        System.out.println("main++++++++++++++");
        Subscriber subscriber = new Subscriber("TWEETS");
        receiveFromQueue(subscriber);
    }
}
