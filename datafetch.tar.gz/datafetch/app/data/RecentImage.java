package data;

import models.ImageRecognition;

import com.avaje.ebean.Ebean;
import com.avaje.ebean.Query;
import com.avaje.ebean.RawSqlBuilder;
import com.fasterxml.jackson.databind.JsonNode;
import helper.Counter;
import helper.DatetimeHelper;
import helper.JsonHelper;
import helper.TweetWrapper;
import models.ImageRecognition;
import models.Topics;
import twitter4j.HashtagEntity;
import twitter4j.Status;

import java.io.*;
import java.net.URL;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class RecentImage {

    public static JsonNode getRecentImages(int entityId, Date startTime, Date endTime, int maxRows)
    {
        List<ImageRecognition> imageCounterList = Ebean.find(ImageRecognition.class).where().eq("entity_id", entityId).orderBy().
                desc("count").setMaxRows(maxRows).findList();

        List<ImageAggregate> imageAggregates = new ArrayList<>();

        for (ImageRecognition imageCounter : imageCounterList )
        {
            imageAggregates.add(new ImageAggregate(imageCounter.getName(),
                    imageCounter.getCount()));
        }

        return JsonHelper.jsonify(imageAggregates);
    }


    public static void fun(ArrayList<String> reslist , Date trimmedDate , List<Integer> presentEntities)
    {
        for(int i = 0 ; i<reslist.size() ; i++) {
            String res = reslist.get(i);
            for (Integer entityId: presentEntities)
            {
                ImageRecognition ir = Ebean.find(ImageRecognition.class).where()
                        .eq("name", res)
                        .eq("entity_id", entityId)
                        .eq("created_at", trimmedDate)
                        .findUnique();

                if (ir == null) {
                    ir = new ImageRecognition();
                    ir.count = 1;
                    ir.createdAt = trimmedDate;
                    ir.name = res;
                    ir.entityId = entityId;
                } else {
                    ir.setCount(ir.count + 1);
                }
                System.out.println("Entity id: "+entityId+" has count: "+ir.count);
                Ebean.save(ir);
            }

        }
        //System.out.println(";;;;;;;;;;;;;;;;;;;;;;;;;;;;DONE::::::::::::::::");
    }
}
