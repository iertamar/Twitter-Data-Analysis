package data;

import com.avaje.ebean.Ebean;
import com.avaje.ebean.Query;
import com.avaje.ebean.RawSqlBuilder;
import com.fasterxml.jackson.databind.JsonNode;
import helper.Counter;
import helper.DatetimeHelper;
import helper.JsonHelper;
import helper.TweetWrapper;
import models.HashtagCounter;
import models.ImageRecognition;
import models.Topics;
import twitter4j.HashtagEntity;
import twitter4j.Status;

import java.io.*;
import java.net.URL;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ImageRepo {
    static int i = 0;
    public static void imageAnalysis(TweetWrapper tweetWrapper , List<Integer> presentEntities){
        Status status = tweetWrapper.status ;

       // System.out.println("After-------------------------");

        if(status.getMediaEntities().length>=1)
        {
            try{

                String address="";
                address = status.getMediaEntities()[0].getMediaURL();
                //System.out.println(address);
                String tempstr = "";
                for(int j = address.length()-1 ; j>=0; j--)
                {
                    if(address.charAt(j)=='.')
                    {
                        tempstr = address.substring(j , address.length() );
                        break ;
                    }
                }
                if(tempstr.equals(".jpg"))
                {
                    //System.out.println("=============");
                    String destinationFile = "/home/amar/Desktop/twitter_project/models-master/tutorials/image/imagenet/images/"           + i +tempstr ;
                   // System.out.println("......................");
                    saveImage(address , destinationFile );
                    //System.out.println("before+++++++++++++");
                    Date trimmedDate = DatetimeHelper.getDateUptoHours(status.getCreatedAt());
                    ArrayList<String> res = ImgRecognition(i , tempstr);
                    //System.out.println(res+"     after returning  :      ");
                    RecentImage.fun(res , trimmedDate , presentEntities );
                    i++ ;
                }
            }
            catch(Exception e)
            {
                System.out.println("Error while uploading image onto one folder----You may have change your main folder name ");
            }
        }
        System.out.println("Image processing done");
        //
    }

    public static void saveImage(String imageUrl, String destinationFile) throws IOException {
        URL url = new URL(imageUrl);
        InputStream is = url.openStream();
        OutputStream os = new FileOutputStream(destinationFile);
        System.out.println("Url of the image: "+imageUrl);
        byte[] b = new byte[2048];
        int length;

        while ((length = is.read(b)) != -1) {
            os.write(b, 0, length);
        }

        is.close();
        os.close();
    }

    public static ArrayList<String> ImgRecognition(int number , String tempstr)
    {
        String num = "" ;
        //System.out.println(number+"+++++++++++++");
        ArrayList<String> listTemp = new ArrayList<>();
        try
        {
            String s = "";
            Process p=null;
            try{

                p = Runtime.getRuntime().exec("python3 /home/amar/Desktop/twitter_project/models-master/tutorials/image/imagenet/classify_image.py --image_file /home/amar/Desktop/twitter_project/models-master/tutorials/image/imagenet/images/"+number+tempstr);
                //System.out.println("lllllllllll");
            }
            catch(Exception e)
            {
                System.out.println("file not found");
            }

            BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));

            //System.out.println("Here is the standard output of the command:\n");
            String temp = "" ;

            //System.out.println(br.readLine()+" = before");
            while ((s = br.readLine()) != null)
            {
                num = "" ;
                //listTemp = new ArrayList<>();
                System.out.println(s);
                for(int i = 0; i<s.length() ; i++)
                {
                    num = s.substring(s.length()-6 , s.length()-4);
                    if (Integer.parseInt(num)>5)
                    {
                        if (s.charAt(i) != ',' && s.charAt(i) != '(')
                            temp = temp + s.charAt(i);
                        else
                        {
                            if (s.charAt(i) == ',') {
                                listTemp.add(temp);
                                i++;
                                //System.out.println(temp);
                                temp = "";
                            }
                            else if(s.charAt(i) == '(')
                            {
                                listTemp.add(temp.substring(0 , temp.length()-1));
                                temp = "" ;
                                break ;
                            }
                        }
                    }

                }
                //System.out.println();
                return listTemp ;
            }
          // System.out.println("   After   ^^^^^^^^^^  "+listTemp);

        }
        catch(Exception e)
        {

        }
        ArrayList<String> nu = new ArrayList<>();
            return nu ;
    }
}