SET FOREIGN_KEY_CHECKS=0;

drop table entity;

drop table handle;

drop table hashtag_counter;

drop table keyword;

drop table talkers;

drop table token;

drop table tweets;

SET FOREIGN_KEY_CHECKS=1;

